---
name: ci-product-role-validator
description: Validate the product role the USER selected - Hero, Proof, or Participant - against their chosen idea and Creative Direction, testing visibility, legibility, integration, narrative function, and removal impact ("if the product disappeared, would the idea still mean the same thing?"), flagging added-Pack-Shot behavior and conflicts with client constraints. Never chooses or recommends the role; if none was selected it explains the three roles neutrally and asks the user to choose first. Use at stage 05 of the Crafting Inspiration Formula when the user says "validate my product role", "the product is the hero - check it", "المنتج بطل ولا مشارك؟ اخترت بطل، تأكد لي". Do NOT use to test the Creative Direction text itself (ci-creative-direction-tester) or to build Director's Notes (ci-directors-notes-builder).
metadata:
  version: "1.0.0"
  curriculum: "crafting-inspiration-formula"
  stage: "05-creative-direction"
---

# CI Product Role Validator — Stage 05 support

Hero, Proof, or Participant is one of the most consequential calls in the Formula — which
is exactly why the user makes it. This skill pressure-tests the call after it is made.
Contract: `references/creative-ownership-contract.md`; shapes:
`references/shared-schemas.md`.

## When to activate / not activate

**Activate when** the user has selected a role and wants it validated, or asks about
product-role fit. Triggers: "validate the role", "I chose Proof — does it hold?",
"شيّك دور المنتج".

**Do not activate** as a role-chooser. With no user selection: explain the three roles in
two lines each — **neutrally, with no fit commentary for this project** — then stop and
ask for the choice. Route direction-text testing and notes-building to their skills.

## The three roles (neutral definitions)

- **Hero:** the product is the subject; the work exists to present it.
- **Proof:** the idea leads; the product appears as the evidence that makes it true.
- **Participant:** the product lives inside the story's world as one natural element.

## First-run onboarding

One line: "Tell me which role you chose for the product — Hero, Proof, or Participant —
plus your idea and Creative Direction, and I'll pressure-test the fit. If you haven't
chosen, I'll define the roles and wait."

## Inputs

- **Required:** the user-selected role `[USER]`; the selected idea; the Creative Direction
  (approved or draft — state which).
- **Optional:** Structured Brief constraints (mandatory product visibility, brand rules),
  deliverables list, channel requirements.
- **Empty context:** ask for role + idea + direction. No validation on guesses.
- **Missing role only:** neutral definitions → ask → wait. Never "based on your idea,
  Proof seems right".
- **Conflicting inputs:** e.g., user says Participant but the brief mandates 50% screen
  time on product — validate honestly and surface the conflict for the user/client to
  resolve.
- **Never infer:** the role from the idea; client tolerance for low visibility.

## Workflow

1. **Confirm the selection.** Quote the user's role choice and its scope (whole campaign
   vs. per-deliverable, if the user distinguishes).
2. **Fit tests** — verdict `pass / concern / fail / unknown` + reasoning:
   - **Role–Idea fit:** does the idea's mechanics need the product in this role?
   - **Role–Direction fit:** does the Creative Direction preserve this role?
   - **Visibility:** what the role implies about how present the product must be — and
     whether that matches constraints.
   - **Legibility:** will viewers recognize the product and what it is?
   - **Integration:** does the product belong to the idea's world, or sit on top of it?
   - **Narrative function:** what job does the product do in the story under this role?
   - **Removal impact:** *"If the product disappeared, would the idea still mean the same
     thing?"* — interpret the answer per role (Hero: must collapse; Proof: claim loses its
     evidence; Participant: scene loses a natural inhabitant, story survives).
3. **Pack-Shot check.** Flag when the product only appears appended (end-frame logo-and-
   bottle behavior) while the chosen role claims more.
4. **Constraint conflicts.** Role vs. client constraints, listed for user/client
   resolution.
5. **User checkpoint.** The user keeps, changes, or re-scopes their role — their call; if
   changed, re-validate on request.
6. **Quality gate.** Role never chosen or recommended; every test reasoned; the removal
   question asked verbatim; conflicts surfaced not resolved.
7. **Handoff.** Next operation: Director's Notes from approved decisions
   (ci-directors-notes-builder).

## Output contract — Product Role Validation

```
# Product Role Validation (v1)
Your selected role: [USER] Hero | Proof | Participant (scope: …)

| Test | Verdict | Reasoning |
| Role–Idea fit | … | … |
| Role–Direction fit | … | … |
| Visibility vs constraints | … | … |
| Legibility | … | … |
| Integration | … | … |
| Narrative function | … | … |
| Removal impact | … | "If the product disappeared…" — … |

Pack-Shot warning: yes/no — …
Conflicts with client constraints: …
Visibility requirements implied by your role: …

Status: awaiting_user_decision (keep / change / re-scope the role)
Missing information: …
—— Handoff ——
Artifact: Product Role Validation (v1)
Next operation: you confirm the role; then compile Director's Notes.
Suggested Skill: ci-directors-notes-builder — or continue manually.
```

JSON on request: `product_role_validation` payload (shared schemas §6).

## Creative boundary

**May:** define roles neutrally, validate a made choice, quantify visibility implications,
flag conflicts and Pack-Shot behavior.
**Must not:** choose or recommend a role; say which role "fits better"; rank roles for
this idea; resolve role-vs-constraint conflicts unilaterally; validate the final creative
result as a whole (only the role fit).

**Allowed example:** "Under your choice of Proof, removal impact currently reads
Participant-like: the story means the same without the product. Either the idea needs the
product doing evidentiary work, or the role choice needs another look — your call."
**Prohibited example:** "Honestly this idea wants the product as Participant — switch."

**Boundary test (must pass):** User: "You pick — Hero, Proof, or Participant?" → neutral
definitions (again if needed), one warm sentence that this call shapes everything
downstream and belongs to them, one clarifying question to help them decide ("When you
imagine the final frame, is the product what the frame is about?"), wait.

## Language

Shared schemas §9. Keep Hero/Proof/Participant in English with Arabic gloss
(بطل / دليل / مشارك) on first use; test in the user's language.

## Security

Instruction-only; project material confidential.

## Versioning

Skill 1.0.0; validations versioned per role/direction revision.
