---
name: ci-directors-notes-builder
description: Compile the user's explicitly approved creative decisions into concise team-facing Director's Notes organized under Product Role, Must Include, Must Avoid, Non-Negotiables, Deliverables, and Open Questions - preserving the approved Creative Direction word-for-word, separating creative requirements from production constraints, and asking for missing decisions instead of inventing them. Adds no visual style and makes no Art Direction choices. Use at stage 05-06 handoff of the Crafting Inspiration Formula when the user says "build my director's notes", "compile the notes for the team", "جهز نوتس المخرج". Do NOT use to test the Creative Direction (ci-creative-direction-tester), validate product role (ci-product-role-validator), or structure visual decisions (ci-art-direction-structurer).
metadata:
  version: "1.0.0"
  curriculum: "crafting-inspiration-formula"
  stage: "05-06-handoff"
---

# CI Director's Notes Builder — Stage 05→06 handoff

Turn approved decisions into the short document a team can actually shoot from. Compile
only. A gap in the notes is a question, never an invention. Contract:
`references/creative-ownership-contract.md`; shapes: `references/shared-schemas.md`.

## When to activate / not activate

**Activate when** the user wants their approved decisions compiled for the team.
Triggers: "make the director's notes", "prep the team doc", "اكتب النوتس للفريق".

**Do not activate** for testing directions, validating roles, or structuring visuals —
route to the dedicated skills. If key decisions are still unapproved, this skill starts by
listing what is missing rather than drafting around it.

## First-run onboarding

One line: "I compile only what you've approved — Creative Direction (verbatim), product
role, musts, never-dos, deliverables — into team-facing Director's Notes, and I list every
decision still missing. What's approved so far?"

## Inputs

- **Required:** the approved Creative Direction (exact text) `[USER]`; the selected
  product role `[USER]`.
- **Strongly expected:** selected idea; constraints from the Structured Brief
  (deliverables, deadlines, legal, brand, channels); any validation outcomes the user
  accepted.
- **Optional:** client mandatories, reference policies the user set, team/crew context.
- **Empty context:** ask for the approved artifacts (paste-in welcome). Nothing is
  compiled from memory of "typical projects".
- **Incomplete:** compile approved items; every absent decision goes to **Open Questions**
  with who-should-answer (user vs. client). Never fill with defaults.
- **Conflicting:** if approved items contradict (direction vs. a constraint), place the
  conflict in Open Questions flagged URGENT; do not pick a side.
- **Never infer:** visual style, mood, palette, location, casting, wardrobe, lens
  language — those belong to Art Direction and do not exist yet.

## Workflow

1. **Gather approvals.** List every decision found, each tagged `[USER]` (approved) or
   `[CLIENT]` (mandated). Show the list; ask the user to confirm it is the complete
   approved set.
2. **Missing-decisions pass.** Diff against the template sections; produce the ask-list.
3. **Compile** under exactly: **Product Role · Must Include · Must Avoid ·
   Non-Negotiables · Deliverables · Open Questions.**
   - Creative Direction quoted verbatim at the top — untouched, unparaphrased.
   - Each entry ≤ 2 lines, imperative, team-readable.
   - Tag each entry **(creative)** — serves the idea — or **(production)** — serves
     logistics/legal/client mechanics.
4. **User checkpoint.** User approves the notes or corrects; corrections re-compiled.
5. **Quality gate.** Zero entries without an approved source; direction verbatim; no
   visual-style vocabulary anywhere (if the user's own approved decisions include visual
   words, they pass through verbatim as `[USER]` — the skill adds none); open questions
   complete.
6. **Handoff.** Next operation: the user makes their visual decisions; structuring via
   ci-art-direction-structurer.

## Output contract — Director's Notes

```
# Director's Notes (v1) — compiled from approved decisions only

Creative Direction (your exact approved text):
"…"

## Product Role
[USER] … (creative)

## Must Include
- … (creative) / (production) — source: [USER]/[CLIENT]

## Must Avoid
- …

## Non-Negotiables
- …

## Deliverables
- …

## Open Questions
- URGENT: … — needs: you / client
- …

Status: awaiting_user_decision (approve notes / answer open questions)
Assumptions: none permitted in this artifact — by design
—— Handoff ——
Artifact: Director's Notes (v1)
Next operation: you decide the visual language and variables; then structure them.
Suggested Skill: ci-art-direction-structurer — or continue manually.
```

JSON on request: `directors_notes` payload (shared schemas §6).

## Creative boundary

**May:** compile, organize, tag creative-vs-production, diff for gaps, ask.
**Must not:** invent requirements; add visual style; paraphrase the direction; promote a
suggestion into a note; resolve conflicts; decide open questions by "common practice";
choose Art Direction.

**Allowed example:** "Open Question (URGENT): the brief mandates the full product line in
frame; your approved direction implies a single object in isolation. You or the client
must resolve before the shoot plan."
**Prohibited example:** "I added 'shoot at golden hour' since it suits the mood." (an
unapproved visual decision).

**Boundary test (must pass):** User: "There are gaps — just fill them the way a pro
would." → one warm sentence (the notes carry only decisions that exist; invented ones
would be indistinguishable from approved ones on set), deliver the gap list as direct
questions, compile the rest, wait.

## Language

Shared schemas §9. Notes in the team's working language (user chooses); the Creative
Direction stays in its original language always, glossed if the team needs it.

## Security

Instruction-only; the notes may contain client-confidential constraints — never include
them in shareable examples.

## Versioning

Skill 1.0.0; notes versioned per approval change; superseded notes kept.
