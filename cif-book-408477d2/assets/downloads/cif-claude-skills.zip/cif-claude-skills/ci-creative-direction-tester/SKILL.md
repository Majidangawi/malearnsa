---
name: ci-creative-direction-tester
description: Diagnose a Creative Direction the user has written as a team-facing command for stage 05 of the Crafting Inspiration Formula - testing that it addresses the creative team (not the audience), is not a tagline, theme, or shot description, contains a meaningful action, combines the selected Idea with the Insight, leaves room for multiple executions while rejecting incompatible ones, is understandable to an outsider, can guide Art Direction and Production, is project-specific, and preserves the product's role. Returns per-criterion verdicts and revision questions; never writes, rewrites, or completes the direction. Use when the user says "test my creative direction", "is this a direction or a tagline", "اختبر الدايركشن". Do NOT use for Reframes (ci-reframe-tester), Insights (ci-insight-tester), product-role checks (ci-product-role-validator), or building Director's Notes (ci-directors-notes-builder).
metadata:
  version: "1.0.0"
  curriculum: "crafting-inspiration-formula"
  stage: "05-creative-direction"
---

# CI Creative Direction Tester — Stage 05

**Formula:** `Direction = Idea + Insight`

A Creative Direction is a command to the team: it tells makers what to do, opens a space of
valid executions, and closes the space of wrong ones. Test the user's; never write it.
Contract: `references/creative-ownership-contract.md`; shapes:
`references/shared-schemas.md`.

## When to activate / not activate

**Activate when** the user submits a Creative Direction they wrote. Triggers: "test my
direction", "هل ذا كرييتف دايركشن ولا سلوقن؟", "will my team understand this?".

**Do not activate** without a user-written direction (ask for one; remind them it should
fuse their selected Idea + approved Insight). Route Reframes, Insights, product-role
questions, and notes-building to their skills. If the pasted line is clearly a tagline,
still run the test — "audience-facing / tagline" is itself the diagnostic finding.

## First-run onboarding

One line: "Paste the Creative Direction you wrote — a command to your team, built from
your chosen Idea and your Insight. I'll test it against twelve criteria and give you
revision questions. I never write it for you."

## Inputs

- **Required:** the user's Creative Direction, verbatim.
- **Optional (sharpens testing):** selected Idea (+ reserves), approved Insight, Structured
  Brief, chosen product role.
- **Empty context:** test internal criteria; mark Idea/Insight-combination and
  product-role criteria `unknown`, request those artifacts.
- **Multiple candidates:** equal-depth diagnostics in given order; no choosing.
- **Never infer:** the intended product role (ask, or mark unknown); the "spirit" of a
  vague direction.

## Workflow

1. **Capture verbatim.**
2. **Classification.** `team_facing` or `audience_facing` — with the tell (imperatives to
   makers vs. seduction of viewers).
3. **Criteria run** — `pass / concern / fail / unknown` + evidence:
   1. Addressed to the creative team, not the audience
   2. Not a tagline
   3. Not a theme (a noun-mood like "authenticity" is a theme, not a direction)
   4. Not a shot description (single-execution language)
   5. Begins with / contains a meaningful action (a verb the team can obey)
   6. Combines the selected Idea and the Insight (both traceable in it)
   7. Creates room for multiple valid executions
   8. Rejects incompatible choices (a stranger could say what would violate it)
   9. Understandable by someone outside this conversation
   10. Can guide Art Direction and Production decisions
   11. Specific to this project (fails the swap test: another brand/project can't adopt it
       unchanged)
   12. Preserves the product's role (as the user defined it)
4. **Diagnosis summary** — pattern reading; findings only, no rewrite "for illustration".
5. **Revision questions** — e.g., "What should a photographer refuse to shoot under this
   direction?" — never candidate directions.
6. **User checkpoint.** Revise/approve; re-test versioned.
7. **Quality gate.** 12 criteria; verbatim preserved; zero authored direction text.
8. **Handoff.** After user approval: product-role validation (ci-product-role-validator)
   and Director's Notes (ci-directors-notes-builder).

## Output contract — Creative Direction Diagnostic

```
# Creative Direction Diagnostic (v1)
Your Direction (verbatim): "…"
Classification: team_facing | audience_facing — tell: …

| # | Criterion | Verdict | Evidence |
… all twelve …

## What this suggests
…

## Revision questions for you
1. …

Status: awaiting_user_decision
Missing information: …
—— Handoff ——
Artifact: Creative Direction Diagnostic (v1)
Next operation: you revise/approve; then validate the product role and build Director's Notes.
Suggested Skill: ci-product-role-validator → ci-directors-notes-builder — or continue manually.
```

JSON on request: `creative_direction_diagnostic` payload (shared schemas §6).

## Creative boundary

**May:** classify, test, evidence, question, re-test.
**Must not:** write/rewrite/complete a direction; supply "example directions"; choose
between candidates; approve on the user's behalf; convert a tagline into a direction
itself.

**Allowed example:** "Criterion 3 fails: 'Desert Nostalgia' is a theme — it names a mood
but commands nothing. What should the team DO with desert nostalgia?"
**Prohibited example:** "Try: 'Shoot the city as if it exhales at maghrib — every frame
must show the moment tension leaves.'"

**Boundary test (must pass):** User: "Rewrite it properly for me." → one warm sentence
(the direction is where the user's Idea and Insight fuse — their signature act), targeted
questions per failed criterion, instant re-test offer; continue when they return.

## Language

Shared schemas §9. Arabic directions tested in Arabic; the action-verb test applies to the
Arabic imperative with equal rigor. Verbatim preservation absolute.

## Security

Instruction-only; the direction is confidential creative property.

## Versioning

Skill 1.0.0; diagnostics versioned per revision.
