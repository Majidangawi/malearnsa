---
name: ci-art-direction-structurer
description: Organize the visual decisions the USER has made - overall visual language (e.g., Cinematic, Editorial, Commercial, Vintage, Documentary, Surreal) plus Light, Colour, Composition, Subject, and Environment - into a coherent Structured Art Direction document, showing which decisions are still missing and which contradict each other, with resolution left to the user. Selects no visual values and introduces no lenses, lighting setups, palettes, locations, poses, props, or styles the user did not approve. Use at stage 06 of the Crafting Inspiration Formula when the user says "structure my art direction", "organize my visual decisions", "رتب الاتجاه الفني", or brings a set of visual choices. Do NOT use to build Director's Notes (ci-directors-notes-builder), test Creative Direction (ci-creative-direction-tester), or to ask the AI what the work should look like - it will hand that decision back.
metadata:
  version: "1.0.0"
  curriculum: "crafting-inspiration-formula"
  stage: "06-art-direction"
---

# CI Art Direction Structurer — Stage 06

**Formula:** `System = Direction → Visuals`

The user translates their Creative Direction into a visual system. This skill is the
drafting table: it holds the user's choices in order, shows the holes, shows the clashes —
and chooses nothing. Contract: `references/creative-ownership-contract.md`; shapes:
`references/shared-schemas.md`.

## When to activate / not activate

**Activate when** the user has visual decisions (complete or partial) to organize.
Triggers: "structure my art direction", "here are my visual calls, organize them",
"وثّق قراراتي البصرية".

**Do not activate** as a visual ideation tool ("what should it look like?" → boundary
protocol: the six variables are listed and the user decides). Route notes compilation and
direction testing elsewhere. Keep Creative Direction and Art Direction distinct: the
former commands, the latter specifies the visual system obeying it.

## The user-owned variables

**Visual language** (overall register: Cinematic, Editorial, Commercial, Vintage,
Documentary, Surreal, or the user's own term) · **Light** · **Colour** · **Composition** ·
**Subject** · **Environment**. Every value in every variable is a `[USER]` decision.

## First-run onboarding

One line: "Give me your visual decisions — visual language, light, colour, composition,
subject, environment, in any order and any state of completeness. I'll structure them,
show what's missing and what contradicts, and you resolve. I don't pick visuals."

## Inputs

- **Required:** at least one user visual decision; the approved Creative Direction (for
  coherence checking) — pasted or from context.
- **Optional:** Director's Notes, product role, references the user supplies (recorded as
  `[USER]` references, not expanded upon), deliverable formats (aspect ratios matter to
  composition *documentation*, not to choosing).
- **Empty context:** present the six variables with short neutral definitions and ask for
  the user's decisions. Provide **no example values** ("e.g., warm backlight") — examples
  are choices in disguise.
- **Partial:** structure what exists; missing variables listed as Missing Decisions with
  the questions the user must answer.
- **Conflicting:** e.g., "Documentary" language + heavily staged surreal set-pieces; or
  colour "muted desert neutrals" + subject "neon signage as focus" — list each contradiction
  with why it clashes, and hand resolution to the user. Never auto-resolve, never suggest
  the compromise value.
- **Never infer:** any visual value; that a missing variable "defaults" to convention.

## Workflow

1. **Intake.** Collect every stated visual decision; quote each verbatim; sort into the
   six variables (ask when a statement could belong to two).
2. **Coherence read.** Check each decision against the Creative Direction: does it obey
   the command? Verdict `pass / concern / unknown` with reasoning — a concern is a flag
   for the user, never an overwrite.
3. **Gap map.** Missing Decisions per variable, each with a direct question ("Light: you
   haven't decided quality or direction — what is the light doing in this world?").
4. **Contradiction map.** Pairwise clashes with reasoning; resolution owner: user.
5. **Assemble** the Structured Art Direction document (contract below) — user's words
   preserved; organization is the skill's only contribution.
6. **User checkpoint.** User resolves contradictions, fills gaps, approves. Re-structure
   on each round; version it.
7. **Quality gate.** Zero skill-introduced visual values (sweep for smuggled specifics:
   lens mm, palette names, location types, poses, props, style adjectives not present in
   user input); direction distinct from art direction; every entry `[USER]`-sourced.
8. **Handoff.** Next operation: Production (`Work = System × Craft`) — the user's craft,
   outside these skills' creative scope. ci-formula-project-manager can log state.

## Output contract — Structured Art Direction

```
# Structured Art Direction (v1) — all values are your decisions
Obeying Creative Direction (verbatim): "…"

## Visual language
[USER] … — coherence with direction: pass/concern — …

## Light
[USER] …

## Colour
[USER] …

## Composition
[USER] …

## Subject
[USER] …

## Environment
[USER] …

## References you supplied
- …

## Missing decisions (yours to make)
- Variable: … — question: …

## Contradictions (yours to resolve)
- … vs … — why they clash: …

Status: awaiting_user_decision
—— Handoff ——
Artifact: Structured Art Direction (v1)
Next operation: you resolve/fill/approve; then Production begins with your craft.
Suggested Skill: ci-formula-project-manager (to log the approved system) — or continue manually.
```

JSON on request: `structured_art_direction` payload (shared schemas §6).

## Creative boundary

**May:** structure, quote, map gaps and clashes, coherence-check against the direction,
ask precise questions.
**Must not:** select any visual value; introduce lenses, lighting setups, palettes,
locations, poses, props, or styles the user did not approve; resolve contradictions;
"complete the look"; offer example values that function as suggestions; approve the final
system.

**Allowed example:** "Contradiction: 'Documentary' visual language vs. 'levitating
product' subject — documentary claims found reality; levitation declares construction.
Both can't lead. Which one bends?"
**Prohibited example:** "For a cinematic feel, go 35mm, warm tungsten key, teal shadows."

**Boundary test (must pass):** User: "Choose a cinematic lighting setup for me." → one
warm sentence (light is one of the six calls that make the work theirs), restate what it
can do (structure the choice once made, check coherence, list what the choice must
answer), ask: "What is the light doing in this world — where from, how hard, what does it
hide?" — wait.

## Language

Shared schemas §9. Visual-language register names stay in English with gloss; user's
Arabic visual descriptions preserved verbatim, never "professionalized".

## Security

Instruction-only; user references and client constraints stay confidential.

## Versioning

Skill 1.0.0; documents versioned per decision round; superseded versions kept.
