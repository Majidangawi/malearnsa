# Crafting Inspiration Formula — Canonical Vocabulary & Interoperability Schemas

**Schema version:** 1.0.0 · Embedded in every CI Skill package so each Skill works standalone.
All CI Skills read and write these shapes. Field names stay in English in every language.

## 1. The Formula (canonical stage names)

| Stage | Operator | Formula | Primary artifact(s) |
|---|---|---|---|
| 00 | Brief Restructure | Structured Brief = Client Input → Required Structure | Structured Brief |
| 01 | Reframe | Reframe = Brief − Assumption | (user's Reframe) · Cliche Map · Reframe Diagnostic |
| 02 | Insight | Insight = Reframe × Tension | (user's Insight) · Provisional ICP · Simulated Persona Session · Insight Diagnostic |
| 03 | Divergence | Pool = Insight × Volume | Formatted Idea Pool |
| 04 | Convergence | Idea = Pool ∩ Constraint | Convergence Analysis · (user's selected Idea) |
| 05 | Creative Direction | Direction = Idea + Insight | Creative Direction Diagnostic · Product Role Validation · Director's Notes |
| 06 | Art Direction | System = Direction → Visuals | Structured Art Direction |
| 07 | Production | Work = System × Craft | (user's produced work) |
| — | Cross-stage | — | Campaign Deconstruction · Formula Project State |

Keep the English operator names (Reframe, Insight, Divergence, Convergence, Creative
Direction, Art Direction) in all languages; add a natural-language gloss on first use.

## 2. Canonical artifact names

Structured Brief · Provisional ICP · Cliche Map · Reframe Diagnostic · Simulated Persona
Session · Insight Diagnostic · Formatted Idea Pool · Campaign Deconstruction · Convergence
Analysis · Creative Direction Diagnostic · Product Role Validation · Director's Notes ·
Structured Art Direction · Formula Project State.

Machine keys (snake_case): `structured_brief`, `provisional_icp`, `cliche_map`,
`reframe_diagnostic`, `simulated_persona_session`, `insight_diagnostic`,
`formatted_idea_pool`, `campaign_deconstruction`, `convergence_analysis`,
`creative_direction_diagnostic`, `product_role_validation`, `directors_notes`,
`structured_art_direction`, `formula_project_state`.

## 3. Status values

Run status (how this Skill run ended):
`complete` · `awaiting_user_input` (missing information) · `awaiting_user_decision`
(creative decision pending) · `blocked` (cannot proceed; reason given).

Artifact approval state (set only by the user):
`draft` · `approved` · `revised` (was approved, upstream changed → needs revalidation) ·
`rejected` (kept, never deleted) · `superseded` (replaced by newer version).

Criterion verdicts (diagnostic Skills): `pass` · `concern` · `fail` · `unknown`.

## 4. Source labels

Every substantive statement in a CI output is traceable to exactly one source type:

- `[CLIENT]` — stated in client input / uploaded material (source-derived)
- `[USER]` — decided or written by the user (user decision)
- `[AI-INFERENCE]` — provisional inference by the Skill; always also listed under Assumptions
- `[UNKNOWN]` — not available; listed under Missing Information
- `[EDU]` — educational interpretation / reconstruction (Campaign Deconstructor and teaching contexts)

Assumption format: `Assumption A<n>: <statement> — basis: <why plausible> — confirm with: <who/how>`.
Missing-information format: `M<n>: <what is missing> — why it matters: <impact> — ask: <ready-to-send question>`.

## 5. Common interchange envelope

Every CI artifact can be exchanged as Markdown (canonical, human-readable) and, when useful,
as JSON in this envelope. A Skill receiving a pasted artifact accepts either form.

```json
{
  "ci_schema": "1.0.0",
  "artifact": "structured_brief",
  "artifact_name": "Structured Brief",
  "produced_by": "ci-briefer",
  "skill_version": "1.0.0",
  "artifact_version": 1,
  "language": "en | ar | mixed",
  "status": "complete | awaiting_user_input | awaiting_user_decision | blocked",
  "approval_state": "draft | approved | revised | rejected | superseded",
  "payload": {},
  "missing_information": [{"id": "M1", "item": "", "why_it_matters": "", "ask": ""}],
  "assumptions": [{"id": "A1", "statement": "", "basis": "", "confirm_with": ""}],
  "user_decisions": {"made": [{"decision": "", "value": ""}], "pending": [""]},
  "recommended_next_step": {"operation": "", "skill": "", "manual_alternative": ""}
}
```

`recommended_next_step` names the next **operation** in the Formula (e.g., "user writes the
Reframe; test it with ci-reframe-tester"). It never makes or implies the creative decision
itself. `manual_alternative` tells the user what to paste where if the next Skill is not
installed.

## 6. Artifact payload field names

- **structured_brief**: `purpose`, `target_audience`, `target_emotions`,
  `constraints_and_limitations` (incl. deliverables, deadlines, budget, legal, mandatory
  product visibility, brand requirements, channel requirements), `explicit_vs_interpreted`,
  `contradictions`, `client_questions`.
- **provisional_icp**: `known`, `inferred`, `unknown`, `profile` (name, age, location, work,
  income_context, environment, routines, hobbies, interests, media_habits, social_context,
  aspirations, pressures, purchase_behavior, category_relationship, cultural_context),
  `locked_by_user`, `corrections_needed`.
- **cliche_map**: `first_interpretation`, `predictable_first_images`, `category_tropes`,
  `overused_elements` (locations, props, lighting, poses, narratives, claims),
  `why_predictable`.
- **reframe_diagnostic**: `reframe_text_user_verbatim`, `criteria` (structure_x_but_y,
  assumption_removed, deeper_than_brief, connected_to_brief, no_solution, not_campaign_idea,
  works_without_brand, specific_enough, not_mere_restatement — each pass/concern/fail/unknown
  + evidence), `questions_for_user`.
- **simulated_persona_session**: `persona_ref`, `simulation_notice`, `transcript`,
  `exit_command_used`, `summary_if_requested`.
- **insight_diagnostic**: `insight_text_user_verbatim`, `classification`
  (fact | problem | observation | tension), `criteria` (audience_voice, desire_present,
  opposing_force, meaningful_but, human_tension, feeling_behind_behavior, beyond_fact,
  beyond_problem, beyond_observation, beyond_demographic, how_did_you_know_specificity),
  `revision_questions`.
- **formatted_idea_pool**: `ideas` [{`id` ("IDEA-01"…, stable), `title`, `concept_user_verbatim`,
  `formatted_summary`, `open_questions`}], `ordering` ("original" unless user chose another
  neutral method), `count`.
- **campaign_deconstruction**: `campaign_facts` (sourced, cited), `sources`,
  `educational_reconstruction` (per Formula stage, each item labelled `[EDU]`),
  `best_teaching_use`, `limitations_and_criticisms`.
- **convergence_analysis**: `criteria_used` (purpose, target_audience, target_emotions,
  constraints_and_limitations, insight_tension), `matrix` [per idea, in input order:
  criterion → pass/concern/fail/unknown + reasoning], `missing_information`,
  `user_selection_request` (choose 1 idea + up to 2 reserves).
- **creative_direction_diagnostic**: `direction_text_user_verbatim`, `classification`
  (team_facing | audience_facing), `criteria` (not_tagline, not_theme, not_shot_description,
  meaningful_action, combines_idea_and_insight, room_for_executions, rejects_incompatible,
  understandable_standalone, guides_art_direction_and_production, project_specific,
  preserves_product_role), `revision_questions`.
- **product_role_validation**: `role_user_selected` (hero | proof | participant — user only),
  `fit_with_idea_and_direction`, `visibility_requirements`, `legibility`, `integration`,
  `narrative_function`, `removal_impact` ("if the product disappeared…"), `pack_shot_warning`,
  `constraint_conflicts`.
- **directors_notes**: `creative_direction_exact_user_text`, `product_role`, `must_include`,
  `must_avoid`, `non_negotiables`, `deliverables`, `open_questions`,
  `creative_vs_production_constraints`.
- **structured_art_direction**: `visual_language_user_choice`, `light`, `colour`,
  `composition`, `subject`, `environment`, `references_user_supplied`, `missing_decisions`,
  `contradictions_for_user`.
- **formula_project_state**: `current_stage`, `artifacts` [{key, artifact_version,
  approval_state, produced_by}], `version_history`, `missing_information`,
  `pending_user_decisions`, `assumptions`, `rejected_options` (kept, never deleted),
  `revalidation_needed` (downstream artifacts affected by upstream change),
  `next_valid_actions`.

## 7. Handoff format

At the end of a run, a CI Skill emits:

```
—— Handoff ——
Artifact: <Artifact Name> (v<n>, <approval_state>)
Next operation: <what the USER does next in the Formula>
Suggested Skill: <slug> — or manually: copy the artifact above into any chat and describe the next operation.
Waiting on you: <pending user decisions / missing info>, if any.
```

No CI Skill requires another CI Skill to be installed. Any required upstream artifact can be
pasted in manually; the Skill validates its shape and asks for whatever is missing.

## 8. Version format

- Skills: semantic versioning `MAJOR.MINOR.PATCH`, starting at `1.0.0`.
- Artifacts: integer versions `v1, v2, …` per project; superseded versions are kept in
  history, never silently overwritten.
- An upstream artifact change marks dependent downstream artifacts `revised` →
  revalidation recommended (never automatic rework).

## 9. Language behavior (all CI Skills)

- Respond in the language the user is using (Arabic → Arabic, English → English, mixed →
  mirror the user's mix) unless asked otherwise.
- Saudi conversational Arabic is welcome; match the user's register — do not force فصحى on a
  casual conversation, and do not force slang on a formal one.
- Keep the English operator names (Reframe, Insight, Convergence…) and all schema field
  names unchanged across languages; gloss them naturally on first use.
- Preserve the user's creative wording **verbatim** when testing, quoting, or formatting.
  Never "improve" creative language unless the user explicitly asks for language editing —
  and even then, edit language only; never add creative content.
